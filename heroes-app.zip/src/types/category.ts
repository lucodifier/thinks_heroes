export interface Category {
  Id: number;
  Name: string;
}