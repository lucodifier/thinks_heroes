import { Category } from "./category";

export interface Hero {
  Id: Number;
  Name: string;
  Category: Category;
}