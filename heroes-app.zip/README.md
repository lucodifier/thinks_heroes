Projeto de lista de herois

## Requisitos

- Versão node: 22.0.0

- pnpm

## Commands

**OBS: pode rodar com npm ou yarn, recomendo o pnpm**

**OBS: mantido o .env no projeto e git para ter os dados configurados**

**Se não tiver o pnpm instalado**

npm install -g pnpm

**Instalar pacotes**

pnpm install

**Rodar o site**

pnpm dev
